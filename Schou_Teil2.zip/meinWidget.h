#include <QWidget>
#include <QObject>
#include "zeichenFeld.h"
class meinWidget : public QWidget
{
Q_OBJECT
private:
    zeichenFeld *meinZeichenFeld = new zeichenFeld;

public:
    meinWidget(QWidget *parent = 0);

private slots:
    void start(void);
    void stop(void);
    void loadFile(void);
    void saveFile(void);
};
