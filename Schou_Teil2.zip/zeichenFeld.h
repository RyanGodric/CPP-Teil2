#include <QWidget>
#include <QFile>
#include <QTimer>
 
class zeichenFeld : public QWidget
{
    Q_OBJECT

    public:
    zeichenFeld(QWidget *parent = 0);

    QTimer *timer;

    void serialize(QFile &file);
    void deserialize(QFile &file);
    void start(void) { timer->start(1); };
    void stop(void) { timer->stop();};

    private:
    int x=225, y=430;
    int xrechteck=230, yrechteck=20;
    int xkreis=100, ykreis=40;
    int punkte = 0;


    protected:
    void paintEvent(QPaintEvent *event);
    void keyPressEvent(QKeyEvent *event);
};







