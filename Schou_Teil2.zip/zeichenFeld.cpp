#include <QtGui>
#include <QMessageBox>
#include <QKeyEvent>
#include "zeichenFeld.h"

QPainter painter;
 
zeichenFeld::zeichenFeld(QWidget *parent) : QWidget(parent)
{
    setPalette(QPalette(QColor(250, 250, 200)));
    setAutoFillBackground(true);

    timer=new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(update()));
}

void zeichenFeld::paintEvent(QPaintEvent *event)
{
    //Avatar
    painter.begin(this);
    painter.setBrush(QBrush(Qt::BDiagPattern));
    painter.drawRect(x, y, 50, 50);

    //Objektrechteck
    if (yrechteck<500){
    painter.begin(this);
    painter.setBrush(QBrush(Qt::green));
    painter.drawRect(xrechteck, yrechteck, 90,10);
    yrechteck++;
}
    //Objektkreis
    if (ykreis<500) {
    painter.begin(this);
    painter.setPen(QPen(Qt::blue,8));
    painter.drawEllipse(xkreis, ykreis, 40,40);
    ykreis++;
}
    //kreise
    painter.begin(this);
    painter.setBrush(QBrush(Qt::red));
    QRectF Rectangle3(370.0, 20.0, 30.0, 30.0);
    painter.drawEllipse(Rectangle3);

    painter.begin(this);
    painter.setBrush(QBrush(Qt::red));
    QRectF Rectangle(410.0, 20.0, 30.0, 30.0);
    painter.drawEllipse(Rectangle);

    painter.begin(this);
    painter.setBrush(QBrush(Qt::red));
    QRectF Rectangle2(450.0, 20.0, 30.0, 30.0);
    painter.drawEllipse(Rectangle2);

    //counter
    painter.begin(this);
    painter.drawText(5, 15, QString::number(punkte) + " Punkte" );
    punkte++;

    painter.end();

}

void zeichenFeld::keyPressEvent(QKeyEvent * event)
{
    if (event->key() == Qt::Key_Left)
    {
        if(x>=25)
          x = x - 25;
        update();
    }

    if (event->key() == Qt::Key_Right)
    {
        if(x<450)
          x = x + 25;
        update();
    }
}


void zeichenFeld::serialize(QFile &file)
{

    QTextStream out(&file);


        out  << "p " << punkte << " " << x << " " << yrechteck << " " << ykreis ;

}
void zeichenFeld::deserialize(QFile &file)
{
    char c;

    QTextStream in(&file);

    while (in.status() == QTextStream::Ok)
    {
        in >> c;
        if (in.status() == QTextStream::ReadPastEnd) break;

        if (c!='p')
        {
            QMessageBox::warning(this, tr("Objektfehler"),
                                 tr("Folgender Objekttyp ist unbekannt: ") + c,QMessageBox::Ok);
            return;
        }

        in >> punkte >> x >> yrechteck >> ykreis;
    }

    update();
}
